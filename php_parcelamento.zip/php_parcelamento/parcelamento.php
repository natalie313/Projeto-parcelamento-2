<?php
    header('Content-Type: text/html; charset=utf-8');

    //variaveis 
    $emprestimo = $_POST["emprestimo"];
    $vezes = $_POST["parcelas"];
    $parcela = 0;
    $cont = 1;

 
    //teste se preencheu o formulario
    if(isset($_POST["emprestimo"]) && !empty($_POST["emprestimo"]) &&
    isset($_POST["parcelas"]) && !empty($_POST["parcelas"])){
        
     switch ($vezes){
        case "primeira":
            echo "<br> Quantidade de parcelas: 24";
            $parcela = ($emprestimo / $vezes) * 1.5;        
        break;
        case "segunda":
            echo "<br> Quantidade de parcelas: 36";
            $parcela = ($emprestimo / $vezes) * 1.5;      
        break;
        case "terceira":
            echo "<br> Quantidade de parcelas: 48";
            $parcela = ($emprestimo / $vezes) * 1.5;      
        break; 
    }
    while ($cont <= $vezes){
        echo"Parcela: " . $parcela;
        $cont++;
    }
}
    else{
        header("location:index.html");
    }

?>
